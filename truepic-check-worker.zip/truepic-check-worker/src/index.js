/**
 * TruePic Check - Cloudflare Worker
 * Educational visual-risk assessment via OpenRouter (free model).
 * No image or result is stored. Only a hashed per-day counter is kept for rate limiting.
 */

const MODEL = "openrouter/free";
const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
const MAX_BYTES = 8 * 1024 * 1024; // 8 MB
const DAILY_LIMIT = 3; // checks per IP per day
const TIMEOUT_MS = 25_000;
const UNAVAILABLE_MSG =
  "The free analysis service is temporarily unavailable. Please try again later.";

const FIXED_DISCLAIMER =
  "This is an educational visual-risk assessment, not proof. It cannot verify whether an image is real, AI-generated, or manipulated. Do not rely on it for legal, safety, or financial decisions.";

const SYSTEM_PROMPT = `You are a cautious visual-risk assessment assistant for an educational tool.
Look only at visible image qualities (for example lighting consistency, edge artifacts, texture or text distortions, compression patterns, repeated patterns, perspective or shadow inconsistencies).

Strict rules:
- This is an educational assessment, never proof.
- Never identify any person or infer identity, age, ethnicity, gender, health, or other private traits.
- Do not perform facial recognition or reverse-image search.
- Never state that an image is definitely real, AI-generated, manipulated, or fake.
- Use uncertainty language such as "may indicate", "could be consistent with", and "cannot verify".
- Suggest practical next steps (check original source, look for context, compare with trusted sources, ask for the original file).

Respond with JSON ONLY (no markdown, no code fences, no extra text) in exactly this shape:
{
  "riskLevel": "low" | "medium" | "high",
  "riskScore": number between 0 and 100,
  "observations": string[],
  "nextSteps": string[],
  "disclaimer": string
}`;

// Strings containing these are dropped from the model output.
const UNSAFE_PATTERNS = [
  /\b(is|was|are)\s+(an?\s+)?(ai[- ]generated|fake|fabricated|photoshopped|deepfake|manipulated|real|authentic|genuine)\b/i,
  /\b(definitely|certainly|undoubtedly|proves?|proof that)\b/i,
  /\b(this (person|man|woman|boy|girl) is|looks like|resembles|identified as)\b/i,
  /\b(ethnicity|ethnic|racial|race of|years old|age of|gender|male|female|pregnan\w*|disease|illness|disabilit\w*|religio\w*|sexual orientation)\b/i,
];

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";
    const allowed = parseAllowedOrigins(env.ALLOWED_ORIGINS);
    const originOk = origin !== "" && allowed.has(origin);

    // CORS preflight
    if (request.method === "OPTIONS") {
      if (!originOk) return new Response(null, { status: 403 });
      return new Response(null, { status: 204, headers: corsHeaders(origin) });
    }

    if (!originOk) {
      return json({ error: "Origin not allowed." }, 403, null);
    }

    const url = new URL(request.url);
    if (request.method !== "POST" || (url.pathname !== "/api/check" && url.pathname !== "/")) {
      return json({ error: "Not found." }, 404, origin);
    }

    // --- Validation -------------------------------------------------------
    const declaredLength = Number(request.headers.get("Content-Length") || 0);
    if (declaredLength > MAX_BYTES + 1024 * 1024) {
      return json({ error: "File too large. Maximum size is 8 MB." }, 413, origin);
    }

    let form;
    try {
      form = await request.formData();
    } catch {
      return json({ error: "Invalid request. Please upload an image." }, 400, origin);
    }

    const consent = String(form.get("consent") || "").toLowerCase();
    if (!["true", "on", "1", "yes"].includes(consent)) {
      return json({ error: "You must confirm consent before analysing an image." }, 400, origin);
    }

    const file = form.get("image");
    if (!file || typeof file === "string" || typeof file.arrayBuffer !== "function") {
      return json({ error: "Please upload an image file." }, 400, origin);
    }
    if (file.size === 0) {
      return json({ error: "The uploaded file is empty." }, 400, origin);
    }
    if (file.size > MAX_BYTES) {
      return json({ error: "File too large. Maximum size is 8 MB." }, 413, origin);
    }

    const bytes = new Uint8Array(await file.arrayBuffer());
    if (bytes.byteLength > MAX_BYTES) {
      return json({ error: "File too large. Maximum size is 8 MB." }, 413, origin);
    }
    const mime = sniffImageType(bytes);
    if (!mime) {
      return json({ error: "Unsupported file type. Please upload a JPEG, PNG, or WebP image." }, 415, origin);
    }

    // --- Rate limit (3 per IP per day) -----------------------------------
    const ip = request.headers.get("CF-Connecting-IP") || "unknown";
    const rlKey = await rateLimitKey(ip);
    const used = await getCount(env, rlKey);
    if (used >= DAILY_LIMIT) {
      return json(
        { error: `Daily limit reached (${DAILY_LIMIT} checks per day). Please try again tomorrow.` },
        429,
        origin,
      );
    }
    await setCount(env, rlKey, used + 1);

    // --- Analysis ---------------------------------------------------------
    try {
      const dataUrl = `data:${mime};base64,${toBase64(bytes)}`;
      const result = await analyseWithOpenRouter(dataUrl, env);
      return json({ ...result, remainingToday: DAILY_LIMIT - (used + 1) }, 200, origin);
    } catch {
      // Don't charge the user's quota for our service failing. Never log details.
      await setCount(env, rlKey, used).catch(() => {});
      return json({ error: UNAVAILABLE_MSG }, 503, origin);
    }
  },
};

// ---------------------------------------------------------------------------
// OpenRouter
// ---------------------------------------------------------------------------

async function analyseWithOpenRouter(dataUrl, env) {
  const apiKey = env.OPENROUTER_API_KEY;
  if (!apiKey) throw new Error("unavailable");

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  let res;
  try {
    res = await fetch(OPENROUTER_URL, {
      method: "POST",
      signal: controller.signal,
      headers: {
        Authorization: `Bearer ${env.OPENROUTER_API_KEY}`,
        "Content-Type": "application/json",
        "X-Title": "TruePic Check",
      },
      body: JSON.stringify({
        model: MODEL,
        temperature: 0.2,
        max_tokens: 800,
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Provide an educational visual-risk assessment of this image. Return JSON only.",
              },
              { type: "image_url", image_url: { url: dataUrl } },
            ],
          },
        ],
      }),
    });
  } finally {
    clearTimeout(timer);
  }

  if (!res.ok) throw new Error("unavailable");

  const data = await res.json();
  const content = data?.choices?.[0]?.message?.content;
  const text = Array.isArray(content)
    ? content.map((p) => (typeof p?.text === "string" ? p.text : "")).join("")
    : content;
  if (typeof text !== "string" || !text.trim()) throw new Error("unavailable");

  return validateModelOutput(text);
}

function validateModelOutput(text) {
  let cleaned = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end <= start) throw new Error("invalid");
  cleaned = cleaned.slice(start, end + 1);

  let obj;
  try {
    obj = JSON.parse(cleaned);
  } catch {
    throw new Error("invalid");
  }

  const level = obj?.riskLevel;
  if (!["low", "medium", "high"].includes(level)) throw new Error("invalid");

  const score = Number(obj?.riskScore);
  if (!Number.isFinite(score)) throw new Error("invalid");

  const observations = cleanList(obj?.observations);
  const nextSteps = cleanList(obj?.nextSteps);
  if (observations.length === 0 || nextSteps.length === 0) throw new Error("invalid");

  return {
    riskLevel: level,
    riskScore: Math.max(0, Math.min(100, Math.round(score))),
    observations,
    nextSteps,
    // Always use our fixed, reviewed disclaimer rather than model text.
    disclaimer: FIXED_DISCLAIMER,
  };
}

function cleanList(value) {
  if (!Array.isArray(value)) return [];
  return value
    .filter((s) => typeof s === "string")
    .map((s) => s.trim().slice(0, 300))
    .filter((s) => s.length > 0 && !UNSAFE_PATTERNS.some((re) => re.test(s)))
    .slice(0, 8);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function parseAllowedOrigins(value) {
  return new Set(
    String(value || "")
      .split(",")
      .map((s) => s.trim().replace(/\/$/, ""))
      .filter(Boolean),
  );
}

function corsHeaders(origin) {
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Max-Age": "86400",
    Vary: "Origin",
  };
}

function json(body, status, origin) {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
  };
  if (origin) Object.assign(headers, corsHeaders(origin));
  return new Response(JSON.stringify(body), { status, headers });
}

function sniffImageType(b) {
  if (b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b.length > 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "image/png";
  if (
    b.length > 12 &&
    b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 &&
    b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50
  ) return "image/webp";
  return null;
}

function toBase64(bytes) {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

// Rate limiting: only a hashed IP + date counter, auto-expiring. No images or results stored.
async function rateLimitKey(ip) {
  const day = new Date().toISOString().slice(0, 10);
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`${ip}|${day}`));
  const hex = [...new Uint8Array(digest)].map((x) => x.toString(16).padStart(2, "0")).join("");
  return `rl:${day}:${hex}`;
}

async function getCount(env, key) {
  const v = await env.RATE_LIMIT.get(key);
  return v ? parseInt(v, 10) || 0 : 0;
}

async function setCount(env, key, n) {
  await env.RATE_LIMIT.put(key, String(n), { expirationTtl: 60 * 60 * 26 });
}
